<?php
if( !defined( 'WP_UNINSTALL_PLUGIN' ) ) {
  echo 'Прямой доступ к файлу, запрещён!';
  exit;
}

global $wpdb;
$wpdb->query( 'DROP TABLE IF EXISTS `banner_content`' );
