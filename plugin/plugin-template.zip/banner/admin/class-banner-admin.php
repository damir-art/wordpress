<?php
class Banner_Admin {
  // Конструктор
  public function __construct() {
    // Создадим лог файла, вместо echo для проверки работы класса
    file_put_contents( BANNER_PLUGIN_DIR . 'log.txt', "Admin\n", FILE_APPEND );
  }
}
