<?php
class Banner_Activate {
  // объявляем статичный метод чтобы вызывать его без создания экземпляра
  public static function activate() {
    // создаём таблицу в БД, если она не существует
    global $wpdb;
    $wpdb->query( 
      "CREATE TABLE IF NOT EXISTS `banner_content` (
      `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
      `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
      PRIMARY KEY (`id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
    // добавляем тестовую запись (%s - экранирование строк, prepare() - подготавливает SQL-запрос для выполнения)
    $query = "INSERT INTO `banner_content` (`id`, `content`) VALUES (NULL, %s)";
    $wpdb->query( $wpdb->prepare( $query, 'Контент 1' ) );
  }
}
