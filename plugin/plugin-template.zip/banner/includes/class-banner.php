<?php
class Banner {
  // Конструктор
  public function __construct() {
    // Создадим лог файла, вместо echo для проверки работы класса
    file_put_contents( BANNER_PLUGIN_DIR . 'log.txt', "Banner\n", FILE_APPEND );
    // Вызываем приватный метод load_dependecies()
    $this->load_dependecies();
    $this->define_admin_hooks();
    $this->define_public_hooks();
  }

  // Метод подключающий классы для работы с админкой и публичной частью
  private function load_dependecies() {
    require_once BANNER_PLUGIN_DIR . 'admin/class-banner-admin.php';
    require_once BANNER_PLUGIN_DIR . 'public/class-banner-public.php';
  }

  // Создаём экземпляр класса Banner_Admin
  private function define_admin_hooks() {
    $plugin_admin  = new Banner_Admin;
  }

  // Создаём экземпляры класса Banner_Public
  private function define_public_hooks() {
    $plugin_public  = new Banner_Public;
  }
}
