<?php
/**
 * Plugin Name: Баннер для сайта
 * Plugin URI: https://damir-art.ru
 * Description: Описание баннера для сайта
 * Version: 1.0
 * Author: Damir
 * Author URI: https://damir-art.ru
 */

// Проверяем на прямой доступ к файлу
if ( !function_exists( 'add_action' ) ) {
  echo 'Прямой доступ к файлу, запрещён!';
  exit;
}

// Определяем свои константы
define( 'BANNER_PLUGIN_DIR', plugin_dir_path( __FILE__ ) ); // путь к корневой папки плагина
define( 'BANNER_PLUGIN_URL', plugin_dir_url( __FILE__ ) ); // путь к корневой папки плагина по URL
define( 'BANNER_PLUGIN_NAME', dirname( plugin_basename( __FILE__ ) ) ); // для переводов, название папки плагина

// var_dump( BANNER_PLUGIN_DIR, BANNER_PLUGIN_URL, BANNER_PLUGIN_NAME );

// Подключаем класс активации плагина
register_activation_hook( __FILE__, 'banner_activate' );
function banner_activate() {
  require_once BANNER_PLUGIN_DIR . 'includes/class-banner-activate.php';
  Banner_Activate::activate();
}

// Подключаем класс banner.php
require_once BANNER_PLUGIN_DIR . 'includes/class-banner.php';
function run_banner() {
  // Создаём экземпляр класса Banner
  $plugin = new Banner;
}
run_banner();
