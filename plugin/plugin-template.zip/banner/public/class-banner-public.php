<?php
class Banner_Public {
  // Конструктор
  public function __construct() {
    // Создадим лог файла, вместо echo для проверки работы класса
    file_put_contents( BANNER_PLUGIN_DIR . 'log.txt', "Public\n", FILE_APPEND );
  }
}
